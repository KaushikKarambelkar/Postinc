<?php
session_start();
require_once('connect_db.php');

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '1644419625575045',
      xfbml      : true,
      version    : 'v2.8'
    });
    FB.AppEvents.logPageView();
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
        <meta charset="utf-8" />
        <title>PostInc-Dashboard</title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <?php require_once('ess/header.php') ?>
        <div class="maindiv">
        <!--?php require_once('ess/sidebar.php') ?-->
        <div class="mainbar">   
            <div class="headerwidth"></div>
            <h1>Mainbar</h1>
            <?php 
 print_r($_SESSION); 

    $stmt = $pdo->query("SELECT * FROM dbimg");
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $num = count($row);
  foreach ($row as $key => $value) {
//    print_r($row);
    echo "<br><b><u>".$key."</u></b>: <br>\n";
    foreach ($value as $col => $val) {
        echo "<b>".$col."</b>: ".$val."<br>\n";
    }
    print_r($value);
  }
  echo "<hr>";

    
    echo "Number of records:".count($row)."<br>";


    $stmt = $pdo->query("SELECT * FROM dbimg WHERE UID='".$_SESSION['UID']."';");
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $num = count($row);

    echo "Displaying:".$num."<hr>";
    print_r($row[0]);

    echo "<br>".$row[0]['UID'];

$i=0;
while ($i < $num) {
    $UID=$row[$i]['UID'];
    $imgID=$row[$i]['imgID'];
    $imgname=$row[$i]['imgname'];
    $description=$row[$i]['description'];
    $extension=$row[$i]['imgtype']; 
    $datestamp=$row[$i]['dt'];
    $i++;

        $path="gallery/".$_SESSION['UID']."/".$_SESSION['UID']."_".$i.".$extension";

        if(!(file_exists($path)))
        {
        $path="gallery/notfound.jpg";
        }
    $attr = getimagesize($path);

    echo              "
    <div id\"poster\" class=\"poster\" id=\"poster_$i\">
        <form method=\"POST\" action=\"\">
        <br /><span class=\"imgtitle\">Product ID: $imgID <br/>Poster Title: $imgname</span><br />
        <img src=\"$path\" class=\"postimg\" id=\"postimg_$i\" alt=\"...loading...\"/>
        <input type=\"hidden\" name=\"cartadd\" value=\"$path\" />
        <input type=\"hidden\" name=\"imgID\" value=\"$imgID\" />
        <p class=\"desc\" id=\"desc\">$datestamp<br> $description <br /> UID: $UID.<br><button type=\"submit\">Add to Cart <br><b style=\"font-size: 160%;\">+</b></button></p>
        </form>
    </div>";
        
    }?>
     <div class="upload">        
       <hr>
            <a href="upload.php">Upload Image</a>
     </div>
        </div>
      </div>
        <?php require_once('ess\footer.php'); ?>
        <!--script type="text/javascript">

        onclick=\"addtocart(document.getElementById('postimg_$i').src)\"

            function addtocart(imgpath)
            {
                window.alert('Added: ' + imgpath);
                items_count = getCookie('items_count');
                document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
                setCookie("items_count", items_count+1, );
            }

            function setCookie(cname, cvalue, exdays)
            {
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires=" + d.toUTCString();
                document.cookie = items_count + "_" + "" + "=" + cvalue + ";" + expires + ";path=/";
            }

            function getCookie(cname)
            {
                var name = cname + "=";
                var decodedCookie = decodeURIComponent(document.cookie);
                var ca = decodedCookie.split(';');
                for (var i = 0; i < ca.length; i++)
                {
                    var c = ca[i];
                    while (c.charAt(0) == ' ')
                    {
                        c = c.substring(1);
                    }
                    if (c.indexOf(name) == 0)
                    {
                        return c.substring(name.length, c.length);
                    }
                }
                return "";
            }
            function checkCookie()
            {
                var items_count = getCookie("items_count");
                {
                    username++;
                        setCookie("username", username, 365);
                }
                setCookie("items_count", username, 365);

            }
        </script-->
    </body>
</html>
