        <div class="header headerwidth">
            <h1 style="float: left; margin: 2px 6%; width: 60%;">PostInc - Dashboard</h1>
            <span style="float: right; width: 20%; z-index: 3; position: relative; margin: 1% 30px; background-color: rgba(238,238,238,1); border-radius: 20px;">
            <?php 
                echo "<b>Welcome</b>, ".$_SESSION['uname'];
                echo "<br><b>Email</b>:  ".$_SESSION['email'];
                echo "<br><a href=\"logout.php\">Log Out</a>";
            ?>
            </span>
        </div>
