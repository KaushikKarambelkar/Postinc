<?php 

phpinfo();
print_r(expression)

echo "Haii";
$servername = "localhost";
$username = "Alca";
$password = "ieffa0bchi";
$dbname = "imgUpload";
mysql_connect($servername,$username,$password) or die(mysql_error());
mysql_select_db($dbname) or die( "Error: Unable to select database");

// $query="SELECT * FROM dbUsers";

// $result=mysql_query($query);

// echo mysql_num_rows($result);


    $query="SELECT * FROM dbUsers";    
    
    $result=mysql_query($query);
    
    echo "Number of records:".strval(mysql_num_rows($result));

       foreach(array_keys($result) as $response)
    {
        echo "$response: ".$result[$response]."<br>";
    }

    echo "<hr>";

    echo "<table border=\"3px\" cellpadding=\"15px\">";
    $i=0;
while ($row = mysql_fetch_array($result))
{
    

echo "
    <tr>";

 //   foreach ($header as key($row))
    {
//                echo '<th>Column header: ' . $header . '</th></tr><tr>';

    }

    foreach ($row as $columnName => $columnData)
    {    if(!(($i++)%2)) continue;
        
 /*    if($j<4 ) {  echo '    
        <td>Column name: ' . $columnName . "; \$row:" .$row[$j] . '</td>
    ';
    $j++;
    }
*/
        echo '    
        <td><b>'.$columnName.'</b>: <i>'.$columnData.'</i></td>
    ';
    }
echo "</tr>
    ";
}
    echo "</table>";

?>

?>