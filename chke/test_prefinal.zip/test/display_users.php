<?php
require_once('connect_db.php');

    $query="SELECT * FROM dbUsers";    
    
    $result=mysql_query($query);
    
    echo "Number of records:".strval(mysql_num_rows($result));

       foreach(array_keys($result) as $response)
    {
        echo "$response: ".$result[$response]."<br>";
    }

    echo "<hr>";

    echo "<table border=\"3px\" cellpadding=\"15px\">";
    $i=0;
while ($row = mysql_fetch_array($result))
{
    

echo "
    <tr>";

 //   foreach ($header as key($row))
    {
//                echo '<th>Column header: ' . $header . '</th></tr><tr>';

    }

    foreach ($row as $columnName => $columnData)
    {    if(!(($i++)%2)) continue;
        
 /*    if($j<4 ) {  echo '    
        <td>Column name: ' . $columnName . "; \$row:" .$row[$j] . '</td>
    ';
    $j++;
    }
*/
        echo '    
        <td><b>'.$columnName.'</b>: <i>'.$columnData.'</i></td>
    ';
    }
echo "</tr>
    ";
}
    echo "</table>";

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        
    </body>
</html>
