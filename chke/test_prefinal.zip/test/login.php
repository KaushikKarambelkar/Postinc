<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
        <script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '1644419625575045',
      xfbml      : true,
      version    : 'v2.8'
    });
    FB.AppEvents.logPageView();
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>

<?php
    require_once('connect_db.php');
echo "<hr>";
   foreach(array_keys($_POST) as $response)
    {
        echo "$response: ".$_POST[$response]."<br>";
    }



    if($_POST['uname']!== "")
    {
//      $query=$pdo->prepare();
      $stmt = $pdo->query("SELECT * FROM dbUsers WHERE uname = '".$_POST['uname']."'");

    }elseif($_POST['email']!== "")
    {
      $query=$pdo->prepare("SELECT * FROM dbUsers WHERE email = '".$_POST['email']."'");
    }
    else
    {
      die("Please enter something you faggot.");
    }

//$stmt = $pdo->query($query);
$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
$num_rows = count($row);

   print_r($row);
echo "<br>";
   print_r($row[0]);
echo "<br>";
echo $row[0]['password'];
echo "<br>";

//echo "Row[\$key]: ".$row[0]."; Row[\$value:] ".$row[$value][0];
// {
//   foreach ($row as $key => $value) {
// //    print_r($row);
//     echo "<b>".$key."</b>: ".$value."<br>\n";
//   }
//   echo "<hr>";
// }







if((($num_rows==0)))
{
    echo "User not registered. Please register.<br>";
    die("<a href=\"#\" onclick=\"window.history.back();\">Go back</a>");
}
elseif((($num_rows>1)))
{
echo "Error with the account. Please contact us at support@postinc.in.<br>";
    die("<a href=\"#\" onclick=\"window.history.back();\">Go back</a>");
}
elseif(($row[0]['password']!==$_POST['psw']))
{
    echo "Incorrect password. Please Enter correct password.<br>";
    die("<a href=\"#\" onclick=\"window.history.back();\">Go bacak</a>");
}

else
{
  echo "<br>It okie.<br>";
  echo "Welcome, ".$row[0]['uname']."<hr>";
}


session_start();

$_SESSION['uname']=$row[0]['uname'];
$_SESSION['email']=$row[0]['email'];
$_SESSION['psw']=$row[0]['password'];
$_SESSION['UID']=$row[0]['UID'];


?>
        </head>
    <body>
<a href="dashboard.php">Dashboard</a>
<div class="pm-button">
  <a href="https://www.payumoney.com/paybypayumoney/#/4DBA9E9BF02B58ECF5CE8010E85F208B">
    <img src="https://www.payumoney.com/media/images/payby_payumoney/new_buttons/22.png" />
  </a>
</div>
 </body>
</html>
