<!DOCTYPE html>
<?php
    session_start();
    if(!(isset($_SESSION['uname']))) die("Please <br><a href=\"user.html\">Log in</a> to upload image.");
?>
<html lang="en">
    <head>
        <meta charset="utf-8" />
                <link rel="stylesheet" href="css/style.css">

        <title>PostInc - Upload Image</title>
        <style>
            .imgblock
            {
                display: none;
            }
        </style>
    </head>
    <body>
            <?php require_once('ess/header.php') ?>
            <div class="maindiv" style="overflow: scroll;">
            <!--php? require_once('ess/sidebar.php') ?-->
                        <div class="headerwidth"></div>
                        <div class="headerwidth"></div>
            <form method="post" action="upload_image.php" enctype="multipart/form-data">
                <h1>Upload Image</h1><br>
            <span id="imgblock1">
                <input type="text" name="imgname[]" placeholder="Name of the Image"><br>
                <input type="file" name="img[]" id="myimage"><br>
                <textarea name="description[]"></textarea><br><br>
            </span>
                <a href="#" onclick="document.getElementById('imgblock2').style.display='block'; document.getElementById('ablock2').style.display='none';" id="ablock2">Upload another image</a>
            <span id="imgblock2" class="imgblock">
                <input type="text" name="imgname[]" placeholder="Name of the Image"><br>
                <input type="file" name="img[]" id="myimage"><br>
                <textarea name="description[]"></textarea><br><br>
            </span>
                <br>
                <br>
                <a href="#" onclick="document.getElementById('imgblock3').style.display='block'; document.getElementById('ablock3').style.display='none';" id="ablock3">Upload another image</a>
            <span id="imgblock3" class="imgblock    ">
                <input type="text" name="imgname[]" placeholder="Name of the Image"><br>
                <input type="file" name="img[]" id="myimage"><br>
                <textarea name="description[]"></textarea><br><br>
            </span>
                <br>
                <button type="submit">Submit</button>
            </form>
        </div>
    </body>
</html>
