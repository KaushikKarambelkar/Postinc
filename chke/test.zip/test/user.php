<?php
    if(isset($_SESSION['uname'])) {die ("You are already logged in. Go to <a href=\"dashboard.php\">Dashboard</a>.");}
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    <style>
        input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

body
        {
            background-image: url("img/1.png");
            background-repeat: no-repeat;
            background-size: 100%;
        }

a
{
    text-decoration: none;

}


/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

/* Extra styles for the cancel button */
.cancelbtn {
    width: auto;
    padding: 10px 18px;
    border-radius: 30px;
    background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 24px 0 5px 0;
    position: relative;
}

img.avatar {
    width: 20%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 60px;

}

modal_init
{
     display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 60px;

}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 0% auto 5% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 60%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}
        close:click
        {

        }

/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoomin 0.6s;
    animation: animatezoomin 0.6s
}


@-webkit-keyframes animatezoomin {
    from {-webkit-transform: scale(0)}
    to {-webkit-transform: scale(1)}
}

@keyframes animatezoomin {
    from {transform: scale(0)}
    to {transform: scale(1)}
}


/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}

div.content
{
    text-align: center;
    margin-top: 15%;
    margin-bottom: 10%;

}

/*login button*/

.myButton {
  -moz-box-shadow:inset 0px -20px 4px 0px #ffffff;
  -webkit-box-shadow:inset 0px -20px 4px 0px #ffffff;
  box-shadow:inset 0px -20px 4px 0px #ffffff;
  background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #ddf), color-stop(1, #f6f6f6));
  background:-moz-linear-gradient(top, #ddf 5%, #f6f6f6 100%);
  background:-webkit-linear-gradient(top, #ddf 5%, #f6f6f6 100%);
  background:-o-linear-gradient(top, #ddf 5%, #f6f6f6 100%);
  background:-ms-linear-gradient(top, #ddf 5%, #f6f6f6 100%);
  background:linear-gradient(to bottom, #ddf 5%, #f6f6f6 100%);
  filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#f6f6f6',GradientType=0);
  background-color:#ffffff;
  -moz-border-radius:16px;
  -webkit-border-radius:16px;
  border-radius:16px;
  border:2px solid #dcdcdc;
  display:inline-block;
  cursor:pointer;
  color:#666666;
  font-family:Arial;
  font-size:15px;
  font-weight:bold;
  padding:12px 31px;
  align-self: center;
  margin: 20px;
  text-decoration:none;
  opacity: 0.9;
  text-shadow:0px 1px 0px #ffffff;
  align-self: center;

}
.myButton:hover {
  background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #f6f6f6), color-stop(1, #ffffff));
  background:-moz-linear-gradient(top, #f6f6f6 5%, #ffffff 100%);
  background:-webkit-linear-gradient(top, #f6f6f6 5%, #ffffff 100%);
  background:-o-linear-gradient(top, #f6f6f6 5%, #ffffff 100%);
  background:-ms-linear-gradient(top, #f6f6f6 5%, #ffffff 100%);
  background:linear-gradient(to bottom, #f6f6f6 5%, #ffffff 100%);
  filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#f6f6f6', endColorstr='#ffffff',GradientType=0);
  background-color:#f6f6f6;
  opacity: 1;
  transition-delay: 1s;
}
.myButton:active {
  position:relative;
  top:1px;
}

</style>
        <script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '1644419625575045',
      xfbml      : true,
      version    : 'v2.8'
    });
    FB.AppEvents.logPageView();
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
    </head>
    <body onload="document.getElementById('id00').style.display='block'">

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.8&appId=1644419625575045";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div id="id00" class="modal">

  <div class="modal-content animate">
<div class="content">
<h2>Welcome to PostInc</h2>
<script type="text/javascript">

  function displaydiv(id1val, id2val)
  {
    document.getElementById(id1val).style.display='block';
    document.getElementById(id2val).style.display='none';
  }
</script>

<!-- <button onclick="displaydiv('id01')" style="width:auto;">Login</button> -->
<a href="#" class="myButton" onclick="displaydiv('id01', 'id00')">Login</a>    <br /><br />
<!-- <button onclick="displaydiv('id02')" style="width:auto;">Register</button> -->
<a href="#" class="myButton" onclick="displaydiv('id02', 'id00')" >Register</a>

<br>
<span style="margin-left: 17%; margin-right: auto;">
        <div
  class="fb-like"
  data-share="true"
  data-width="450"
  data-show-faces="true">
</div>
    </span>
</div>

    <div class="container" style="background-color:#f1f1f1">
    </div>
  </div>
</div>



<div id="id01" class="modal">


  <form class="modal-content animate" method="post" action="login.php" id="login_form">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none';document.getElementById('id00').style.display='block'" class="close" title="Close Modal">&times;</span>
      <img src="img/avatar.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
        <div style="width: 48%; float: left;">
      <label><b>Username</b>
      <input type="text" placeholder="Enter Username" name="uname" required></label>
        </div>
        <div style="width: 48%; float: right;">
      <label><b>E-Mail</b>
      <input type="text" placeholder="Enter Email Address" name="email" required></label>
        </div>

        <span>
      <label><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>
        </span>
<!--       <button type="submit">Login</button>
 -->      <a href="#" class="myButton" onclick="document.getElementById('login_form').submit(); return false;" type="submit" style="width: 60%!important; margin: 2% 20%; text-align:center;">Login</a><br>
        <div class="fb-login-button" data-max-rows="1" data-size="medium" data-show-faces="true" data-auto-logout-link="false"></div>

      <input type="checkbox" checked="checked"> Remember me
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none';document.getElementById('id00').style.display='block'" class="cancelbtn login">Cancel</button>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>
  </form>
</div>

<div id="id02" class="modal">

  <form class="modal-content animate" method="post" action="register.php" id="login_form">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none';document.getElementById('id00').style.display='block'" class="close" title="Close Modal">&times;</span>
      <img src="img/avatar.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label><b>Username:</b></label>
      <input type="text" placeholder="Enter Username" name="uname" required>

      <label><b>E-Mail ID:</b></label>
      <input type="text" placeholder="Enter E-Mail ID" name="email" required>

      <label><b>Password:</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>

      <label><b>Confirm Password:</b></label>
      <input type="password" placeholder="Confirm Password" name="pswcnf" required>

      <button type="submit">Register</button>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="check_register(); document.getElementById('id02').style.display='none';document.getElementById('id00').style.display='block'" class="cancelbtn login">Cancel</button>
    </div>
  </form>
</div>


<script>
    function check_register()
    {

    }


// When the user clicks anywhere outside of the modal, close it

//window.onclick = function(event, modalid) {

// Get the modal
/*var modal = document.getElementById(modalid);

    if (event.target == modal) {
        modal.style.display = "none";
    }
}*/
</script>

    </body>
</html>
