  

<?php

phpinfo();
    
require_once('connect_db.php');

   foreach(array_keys($_POST) as $response)
    {
        echo "$response: ".$_POST[$response]."<br>";
    }


    $query="SELECT * FROM dbUsers WHERE email='".$_POST['email']."'";    

    $result=mysql_query($query);
    
$num = (mysqli_num_rows($result));

    
if(($num!==0))
{
    echo "Email address already registered. Please choose a different email or log in with that email.<br>";
    echo "No. of rows: ".$num;
    die("<br><a href=\"#\" onclick=\"window.history.back();\">Go back</a>");

}

//elseif(($_POST['email']=="")||($_POST['pwd']==""))
//{
//    die("<div style=\"color: red;\">Email: "$_POST['email']."<br>Password: ".$_POST['pwd']."</div>");
//}

//elseif(!(mysql_result($result,0,"password"==$_POST['psw'])))
//{
//    echo "Incorrect password. Please Enter correct password.<br>";
//    die("<a href=\"#\" onclick=\"window.history.back();\">Go bacak</a>");
//}


else
{
  echo "<br>It okie.<br>";

  $query="SELECT * FROM dbUsers";
    $result=mysql_query($query);
  $uidnum=mysql_num_rows($result);

 /* $_POST['uname']="Aakarsh";
  $_POST['pwd']="1234";
  $_POST['email']="alcatrazz.627@gmail.com";
  */

    echo "<hr>".$uidnum;    
  echo "<hr>";
//  $uidnum=35664;

  $uidstr="U".(($uidnum%100000-$uidnum%10000)/10000).(($uidnum%10000-$uidnum%1000)/1000).(($uidnum%1000-$uidnum%100)/100).(($uidnum%100-$uidnum%10)/10).($uidnum%10+1);

  echo $uidstr."<br>";

  //$query = "INSERT INTO dbUsers (UID, uname, password, email) VALUES (mysql_num_rows($result)_1), \$_POST['uname'], \$_POST['pwd'], \$_POST['']"
   
$query = "INSERT INTO dbUsers (UID, uname, password, email) VALUES ('$uidstr', '".$_POST['uname']."','".$_POST['psw']."','".$_POST['email']."');";

//  $query="INSERT INTO dbUsers (UID, uname, password, email) VALUES ('".(myqsl_num_rows($result)+1)."', '".$_POST['uname']."', '".$_POST['pwd']."', '".$_POST['email']."');";
  echo "<hr>";
  $result=mysql_query($query);
  echo "<hr>";
  echo mysql_error($result);
  echo mysql_errno($result);

  echo "<br>".$result;   
  echo "<hr>";

  session_start();

$_SESSION['uname']=$_POST['uname'];
$_SESSION['email']=$_POST['email'];
$_SESSION['psw']=$_POST['psw'];
$_SESSION['psw']=$uidstr;

}
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        Ze Normal page
    </body>
</html>
