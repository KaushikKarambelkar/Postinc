
<!-- ____                                      _____            ____                   ____                          ______                  ______    
|    ~.    |         |       .'.        .-~     ~.         |    ~.    |         | |            |..          |  .~      ~. |         |  .~      ~.  
|____.'_   |_________|     .''```.     :                   |____.'_   |_________| |______      |  ``..      | |           |_________| |          | 
|       ~. |         |   .'       `.   :     _____         |       ~. |         | |            |      ``..  | |           |         | |          | 
|_______.' |         | .'           `.  `-._____.'|        |_______.' |         | |___________ |          ``|  `.______.' |         |  `.______.'  
                                                                                                                                                   -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
       <?php
       require_once('connect_db.php');
         
       session_start();

            //Adding it to the dbase
$stmt = $pdo->query("SELECT * FROM dbimg WHERE UID='".$_SESSION['UID']."'");
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $num = count($row);

  echo "<hr>";

    
    echo "Number of records:".$num."<br>";


            //Get the number of records that already exist
    
/*            if(($num!==0))
            {
                echo "Email address already registered. Please choose a different email or log in with that email.<br>";
                echo "No. of rows: ".$num;
                die("<br><a href=\"#\" onclick=\"window.history.back();\">Go back</a>");

            }
            */

       echo "Uploading for User ID: ".$_SESSION['UID']."<br>";

       if(count(array_keys($_FILES))==0) { die("Upload at least one image. <br><a href=\"upload.php\">Upload Image</a>."); }
 
       if(count(array_keys($_FILES))>3) die("Too many uploads. <br><a href=\"upload.php\">Try again</a>.");
        
       foreach(array_keys($_POST) as $response)
       {
        print_r($response);
        echo ": ";
        print_r($_POST[$response]);
        echo "<br>";
       }

       echo count(array_keys($_FILES))."h<hr>";

$i=0;
        foreach ($_FILES["img"]["error"] as $response => $error) {
        echo($response.": \$response");
        echo($_FILES["img"]["name"][$response]."<br/>");
        echo($_FILES["img"]["type"][$response]."<br/>");
        echo($_FILES["img"]["size"][$response]."<br/>");
        echo($_FILES["img"]["tmp_name"][$response]."<br/>");   
        echo($_FILES["img"]["error"][$response]."<br/>");
        echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>";
        
        //Create the dir, just in case, since PHP does not do that by default
        
        $array = explode('.', $_FILES["img"]["name"][$response]);
        $extension = end($array);

    if ($error == UPLOAD_ERR_OK) {
//        $tmp_name = $_FILES["img"]["tmp_name"][$response];
//        $name = basename($_FILES["img"]["name"][$response]);
//        move_uploaded_file($tmp_name, "data/$name");
        }

 echo       $imgID=$_SESSION['UID']."_".($num+1+$response);

        $target_dir = "gallery/".$_SESSION['UID']."/";

       if(!is_dir($target_dir)) mkdir($target_dir, 0755, true);
        $target_file = $target_dir.$imgID.".$extension";//basename($_FILES[$response]["name"]);
        echo $target_file."<br>";
        
        if (file_exists($target_file)) die("Filename already exists.");

        list($width, $height) = getimagesize('path to image');
            echo "width: " . $width . "<br />";
            echo "height: " .  $height . "<br />";
//      Check image type

//      Check Image dimensions if()


        echo "<pre>";
        if(move_uploaded_file($_FILES['img']['tmp_name'][$response], $target_file))
        {
            echo "File was successfully uploaded.<br>";
            echo "<img src=\"$target_file\" /><br>";

date_default_timezone_set("Asia/Kolkata");

//echo            $query = "INSERT INTO image_table (UID, imgID, imgname, description, imgtype, ts) VALUES ('".$_SESSION['UID']."', '".($imgID)."','".$_POST['imgname']."','".$_POST['description']."', '".$extension."','".date("h:i:sa, d-m-y")."'');";
              // $result=mysql_query($query);
              // echo "a<hr>";
              // echo mysql_error($result);
              // echo mysql_errno($result);


      $stmt = $pdo->prepare("INSERT INTO dbImg (UID, imgID, imgname, description, imgtype, dt) VALUES ('".$_SESSION['UID']."', '".($imgID)."','".$_POST['imgname'][$i]."','".$_POST['description'][$i]."', '".$extension."','".strval(date("h:i:sa, d-m-y"))."');");

      $row = $stmt->execute();
echo      $num_rows = count($row);


        } else
        {
            echo "Error.";
        }
        echo "</pre>";
        $i++;
 }


/*       foreach(array_keys($_FILES) as $response)
       {
        echo($response.": \$response");
        echo($_FILES[$response]["name"]."<br/>");
        echo($_FILES[$response]["type"]."<br/>");
        echo($_FILES[$response]["size"]."<br/>");
        echo($_FILES[$response]["tmp_name"]."<br/>");   
        echo($_FILES[$response]["error"]."<br/>");
        echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>";

        $target_dir = "gallery/".$_SESSION['UID']."/";
        
        //Create the dir, just in case, since PHP does not do that by default
        mkdir($target_dir, 0755, true);
        
        $array = explode('.', $_FILES[$response]["name"]);
        $extension = end($array);

        $imgID=$_SESSION['UID']."_".($num+1);

        $target_file = $target_dir.$imgID.".$extension";//basename($_FILES[$response]["name"]);
        echo $target_file."<br>";
        if (file_exists($target_file)) die("Filename already exists.");
        echo "<pre>";
        if(move_uploaded_file($_FILES[$response]['tmp_name'], $target_file))
        {
            echo "File was successfully uploaded.<br>";
            echo "<img src=\"$target_file\" /><br>";

echo            $query = "INSERT INTO image_table (UID, imgID, imgname, description, imgtype) VALUES ('".$_SESSION['UID']."', '".($imgID)."','".$_POST['imgname']."','".$_POST['description']."', '".$extension."');";
              $result=mysql_query($query);
              echo "a<hr>";
              echo mysql_error($result);
              echo mysql_errno($result);

        } else
        {
            echo "Error.";
        }
        echo "</pre>";


        }
        */
       echo "<hr>";
        ?>
    </body>
</html>
