<?php
    session_start();
    require_once('connect_db.php');
    
    if(defined($_POST['removeItemC'])) { session_unregister($_SESSION['cartitems'][($_POST['removeItemC'])]);}
?>
<style>
    div
    {
        overflow: hidden;
    }
    div.cartitem div 
    {
        margin: 10px 0;
    }
    div.cartitem
    {
        padding: 10px;
        margin: 10px;
        border: 2px solid black;
    }
    div.cartimg img
    {
        width: 80%;
    }
    div.cartimg
    {
        float: left;
        width: 60%;
    }
    div.cartname
    {
        font-size: 135%;
    }
    
    div.cartpricing
    {
        margin: 20px 0px;
    }
    div.cartprice
    {
        width: auto;
        margin-top: 30px!important;
/*        float: left;
        margin-left: 10%!important;*/
    }
    div.caartqty
    {
        width: auto;
/*        float: right;
        margin-right: 10%!important;*/
    }
    
    input[type=number]
    {
        opacity: 0.8;
        padding: 8px 10px;
        transition: all 0.2s ease-in-out;
        text-align: center;
        width: 37%;
        border-radius: 20px;
        border-width: 0px;
    }

    input[type=number]:hover
    {
        opacity: 1;
    }
    
    .cartitem
    {
        opacity: 0.8;
        transition: all 0.7s ease-in-out;

    }

    .cartitem:hover
    {
        transition: all 0.2s ease-in-out;
        opacity: 1;
    }

    .qty, .tot
    {
        padding: 8px 2px;
        width: 40%;
        border-width: 0px;
        background-color: inherit;
    }
    
    .tot
    {
        transform: scale(1.6);
        text-align: center;
    }
    
    .itemrem
    {
        text-decoration: none;
        color: #f00;
    }
</style>
        <div class="sidebar" onmouseover="updateTotal();">
            <div class="headerwidth"></div>
            <h1>Sidebar</h1>
            <h2>Shoppinng Cart</h2>
            <hr>
            <div class="cart">

            <!--div class="cartitem"  id="cartitem_1"><details>
                <summary class="cartname">Poster Name</summary>
                <div class="cartspecs">
                    <div class="cartimg"><img src="gallery/U00002/U00002_3.png"></div>
                    <div class="cartprice">Rs. <input type="text" readonly="readonly" class="qty" id="price_1" value="120"></div>
                    <div class="cartpricing">
                        <div class="cartqty">Qty: 
                            <input type="number" id="qty_1" name="quantity" min="1" max="20" value="1" onchange="updatevalue('price_1', 'qty_1');"></div>
                            <a href="#" class="itemrem" onclick="removeItem('1')">Remove Item</a>
                    </div>
                </div>
            </details></div-->


                <?php
                    
//print_r($_POST);

//    if(!(defined($_POST['cartadd'])))
    {
        $cartImgpath=$_POST['cartadd'];
        $cartImgID=$_POST['imgID'];

            if(!(defined($_POST['removeItemC']))) { unset($_SESSION['cartitems'][($_POST['removeItemC'])]);}
            echo $_POST['removeItemC'];

/*        echo "<u>Before:</u><br>";
        print_r($_SESSION['cartitems']);
        echo "<hr><u>After:</u><br>";*/

        $_SESSION['cartitems'][$cartImgID] = $cartImgpath;
//        asort($_SESSION);
//        print_r($_SESSION['cartitems']);


echo "<hr>"."ImgPath: ".$cartImgpath."; ImgID: ".$cartImgID."<hr>";

//        if(!(session_is_registered($cartitems))) 
        {
//    echo "<br>~~~~~~~~<br>";
//    echo        $_SESSION['cartitems'] = array($cartImgID => $cartImgpath);
//    echo "<br>~~~~~~~~<br>";
//    echo        $_SESSION['cartitems'][$cartImgID] = $cartImgpath;
//    echo $cartImgID;
            }

//        print_r($_SESSION);
    }

    //To add items to the cart

              echo "<hr><u>No. of items in cart: </u>".count($_SESSION['cartitems'])."<br>";
              echo "ImgPath: ".$imgpath."<br>";
echo              $ExC = count(intval($_SESSION['cartitems']));
        print_r($_SESSION['cartitems']);
        $i=0;
foreach($_SESSION['cartitems'] as $ImgID_i => $ImgPath_i)
{
    if($_SESSION['cartitems'][count($_SESSION['cartitems'])-1]==$_SESSION['cartitems'][$ImgID_i]) {continue;}
//    if($i==0) {$i++; break;}
              echo "
              <div class=\"cartitem\"  id=\"cartitem_$i\"><details>
                <summary class=\"cartname\">Poster Name<br>Prod ID: $ImgID_i</summary>
                <div class=\"cartspecs\">
                    <div class=\"cartimg\"><img src=\"$ImgPath_i\"></div>
                    <div class=\"cartprice\">Rs. <input type=\"text\" readonly=\"readonly\" class=\"qty\" id=\"price_$i\" value=\"120\"></div>
                    <div class=\"cartpricing\">
                        <div class=\"cartqty\">Qty: 
                            <input type=\"number\" id=\"qty_$i\" name=\"quantity\" min=\"1\" max=\"20\" value=\"alert(localStorage[\'cartqty_$i\']);\" onchange=\"updatevalue('price_$i', 'qty_$i'); localStorage[\'cartqty_$i\'] = this.value.toString();\">
                        </div>
                        <form method=\"POST\" action=\"\"><input type=\"hidden\" name=\"removeItemC\" value=\"$ImgID_i\">
                        <input type=\"submit\" class=\"itemrem\" onclick=\"removeItem('$i')\" value=\"Remove Item\"></form>
                    </div>
                </div>
            </details></div>
            ";
            $i++;
            //localStorage.getItem('qty_price_$i');
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~





//                            $_SESSION['cartitems'][$cartImgID] = $cartImgpath;

                        //To add items to the cart
/*            foreach($_SESSION['cartitems'] as $cartImgID_i => $cartImgpath_i;)
            {
    
              $imgpath = $cartImgpath_i;
              echo $imgpath;
echo              $ExC = count(intval($_SESSION['cartitems']));

              echo "<div class=\"cartitem\"  id=\"cartitem_$ExC\"><details>
                <summary class=\"cartname\">Poster Name</summary>
                <div class=\"cartspecs\">
                    <div class=\"cartimg\"><img src=\"$imgpath\"></div>
                    <div class=\"cartprice\">Rs. <input type=\"text\" readonly=\"readonly\" class=\"qty\" id=\"price_$ExC\" value=\"120\"></div>
                    <div class=\"cartpricing\">
                        <div class=\"cartqty\">Qty: 
                            <input type=\"number\" id=\"qty_$ExC\" name=\"quantity\" min=\"1\" max=\"20\" value=\"1\" onchange=\"updatevalue('price_$ExC', 'qty_$ExC');\"></div>
                            <a href=\"#\" class=\"itemrem\" onclick=\"removeItem('$ExC')\">Remove Item</a>
                    </div>
                </div>
            </details></div>"
            }
            */

            function clear_cart()
            {
                echo "window.alert('Hi');";
                session_unregister($cartitems);
            }
                ?>
                <input type="text" readonly="readonly" class="tot" id="tot" value="0">
                <button type="reset" onclick="<?php clear_cart(); ?>">Reset</button>
                <button type="Submit">Submit</button>
        </div>
</div>

<script>
    function updatevalue(price_num, val)
    {
//        alert('qty_' + price_num);
//        localStorage[('qty_' + price_num)] = ( document.getElementById(val).value.toString);
//        alert((localStorage[('qty_' + price_num)]).toString);
        document.getElementById(price_num).value = (120 * (document.getElementById(val).value));
        updateTotal();
    }

    function updateTotal()
    { 
        sum = 0;
        netval = document.getElementById("tot");
        price_num = document.getElementsByClassName("qty");
        for (i = 0; i < price_num.length; i++)
        {
            sum = sum + parseInt(price_num[i].value, 10);
            netval.value = String(sum);
        }
    }

    function removeItem(item_id)
    {
        cartitem = document.getElementById('cartitem_' + item_id);
        cartitem.style.display = 'none';
        priceitem = document.getElementById('price_' + item_id).value = 0;
        updateTotal();
    }
</script>