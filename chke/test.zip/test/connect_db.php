<?php

include_once('fix_mysql.inc.php');

echo "Haii<hr>";
// $servername = "localhost";
// $username = "mealca";
// $password = "12345678";
// $dbname = "imgUpload";

//try {

//  $db = new PDO("mysql:host=$servername;dbname=mysql", $username, $password);
  /*** echo a message saying we have connected ***/
//  echo 'Connected to database';

//mysql_connect('localhost', 'username', 'password') or die (mysql_info());
//   mysql_select_database('db_name') or die (mysql_error());

//  mysql_connect($servername,$username,$password) or die (mysql_info());

// } catch (PDOException $e) {

// echo "<hr>".$e."<hr>";

// }
//mysql_select_db($dbname) or die( "Error: Unable to select database");


//mysql_connect($servername,$username,$password);
//mysql_select_db($dbname) or die( "Error: Unable to select database");


$hostname="localhost";
$username="mealca";
$password="12345678";
$dbname="imgUpload";
$usertable="dbUsers";

/* Set up a MySQL connection. The try catch block will display an error
   message if the connection is unsuccessful */

$host = 'localhost';
$db   = 'imgUpload';
$user = 'mealca';
$pass = '12345678';
$charset = 'utf8';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$opt = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $opt);

/* Run your query */
$stmt = $pdo->query('SELECT * FROM dbUsers');
while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
{
	foreach ($row as $key => $value) {
    echo "<b>".$key."</b>: ".$value."<br>\n";
	}
	echo "<hr>";
}


//echo "<hr>";


?>