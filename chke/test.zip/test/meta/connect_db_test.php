<?php

include_once('fix_mysql.inc.php');

echo "Haii";
$servername = "localhost";
$username = "Alca";
$password = "ieffa0bchi";
$dbname = "imgUpload";

//try {

//  $db = new PDO("mysql:host=$servername;dbname=mysql", $username, $password);
  /*** echo a message saying we have connected ***/
//  echo 'Connected to database';

//mysql_connect('localhost', 'username', 'password') or die (mysql_info());
//   mysql_select_database('db_name') or die (mysql_error());

//  mysql_connect($servername,$username,$password) or die (mysql_info());

// } catch (PDOException $e) {

// echo "<hr>".$e."<hr>";

// }
//mysql_select_db($dbname) or die( "Error: Unable to select database");


mysql_connect($servername,$username,$password);
mysql_select_db($dbname) or die( "Error: Unable to select database");



?>